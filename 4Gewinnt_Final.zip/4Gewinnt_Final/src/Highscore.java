import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Highscore extends JFrame implements ActionListener {
	private JComboBox combo1 = new JComboBox();
	private JLabel name = new JLabel("");
	private JLabel wins = new JLabel("");
	private JLabel loses = new JLabel("");
	private JButton accept = new JButton("Auswaehlen");

	public Highscore(String title) throws HeadlessException {
		super();

		buildWindow();

	}

	private void buildWindow() {
		setLayout(null);
		File test = new File(System.getenv("pathtoprofil"));
		System.out.println(test);
		// Alle Profile auflisten...
		String[] DIR = test.list();
		for (int i = 0; i < DIR.length; i++) {

			DIR[i] = DIR[i].substring(0, DIR[i].indexOf('.'));
		}
		combo1 = new JComboBox(DIR);
		combo1.setBounds(40, 35, 200, 30);
		add(combo1);
		accept.setBounds(40, 90, 200, 50);
		accept.addActionListener(this);
		add(accept);
		name.setBounds(40, 140, 200, 30);
		add(name);
		wins.setBounds(40, 170, 200, 30);
		add(wins);
		loses.setBounds(40, 200, 200, 30);
		add(loses);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object src = e.getSource();
		if (src == accept) {
			reader();
		}

	}

	private void reader() {
		BufferedReader bureader; // Lesen
		String pfad = System.getenv("pathtoprofil");
		String profilname = (String) combo1.getSelectedItem();

		try {
			bureader = new BufferedReader(new FileReader(pfad + profilname + ".txt"));
			String zeile1 = bureader.readLine();

			name.setText("Name: " + profilname);
			int w = Integer.parseInt(bureader.readLine());
			int l = Integer.parseInt(bureader.readLine());
			wins.setText("Gewonnen: " + w);
			loses.setText("Verloren: " + l);

		} catch (IOException r) {
			System.out.println("Profil nicht vorhanden");
		}

	}
}
