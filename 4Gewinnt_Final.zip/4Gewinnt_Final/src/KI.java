import java.awt.HeadlessException;

public class KI {
	private int amountOfPlayers;
	public KI() throws HeadlessException {
		amountOfPlayers = 2;
	}

	

	// returns x Value to block Users Win
	public int kiMove(int spielfeld[][], int kiMode) {
		for (int currentPlayer = amountOfPlayers; currentPlayer > 0; --currentPlayer) {
			// horizontal
			for (int y = spielfeld.length - 1; y >= 0; --y) {
				for (int x = 0; x <= spielfeld[y].length - 4; ++x) // -4 sonst gewinn nach rechts nicht mgl.
				{
					if (spielfeld[y][x] == currentPlayer) {
						// Szenario: XXX0
						if (spielfeld[y][x + 1] == currentPlayer && spielfeld[y][x + 2] == currentPlayer
								&& spielfeld[y][x + 3] == 0) {
							// falls nicht unterste Reihe
							if (y != spielfeld.length - 1) {
								if (spielfeld[y + 1][x + 3] != 0) {
									if (spielfeld[0][x + 3] == 0) {
										return x + 3;
									}
								}
							} else {
								if (spielfeld[0][x + 3] == 0) {
									return x + 3;
								}
							}
						}
						// Szenario: XX0X
						else if (spielfeld[y][x + 1] == currentPlayer && spielfeld[y][x + 3] == currentPlayer
								&& spielfeld[y][x + 2] == 0) {
							// falls nicht unterste Reihe
							if (y != spielfeld.length - 1) {
								if (spielfeld[y + 1][x + 2] != 0) {
									if (spielfeld[0][x + 2] == 0) {
										return x + 2;
									}
								}
							} else {
								if (spielfeld[0][x + 3] == 2) {
									return x + 2;
								}
							}
						}
						// szenario: X0XX
						else if (spielfeld[y][x + 3] == currentPlayer && spielfeld[y][x + 2] == currentPlayer
								&& spielfeld[y][x + 1] == 0) {
							// falls nicht unterste Reihe
							if (y != spielfeld.length - 1) {
								if (spielfeld[y + 1][x + 1] != 0) {
									if (spielfeld[0][x + 1] == 0) {
										return x + 1;
									}
								}
							} else {
								if (spielfeld[0][x + 1] == 0) {
									return x + 1;
								}
							}
						}
						// szenario: 0XXX
						else if (x > 0 && spielfeld[y][x + 1] == currentPlayer
								&& spielfeld[y][x + 2] == currentPlayer && spielfeld[y][x - 1] == 0) {
							// falls nicht unterste Reihe
							if (y != spielfeld.length - 1) {
								if (spielfeld[y + 1][x - 1] != 0) {
									if (spielfeld[0][x - 1] == 0) {
										return x - 1;
									}
								}
							} else {
								if (spielfeld[0][x - 1] == 0) {
									return x - 1;
								}
							}
						}
					}
				}
			}
			// vertical
			for (int x = 0; x < spielfeld[1].length; ++x) {
				for (int y = spielfeld.length - 1; y >= 3; --y) {
					if (spielfeld[y][x] == currentPlayer) {
						if (spielfeld[y - 1][x] == currentPlayer && spielfeld[y - 2][x] == currentPlayer
								&& spielfeld[y - 3][x] == 0 && spielfeld[0][x] == 0) {
							return x;
						}
					}
				}
			}
			// diago
			for (int y = spielfeld.length - 1; y >= 3; --y)// 3 weil sonst Gewinn nach oben nicht mgl
			{
				for (int x = 0; x <= spielfeld[y].length - 4; ++x) // -4 weil sonst gewinn nach rechts nicht mgl.
				{
					if (spielfeld[y][x] == currentPlayer) {
						if (spielfeld[y - 1][x + 1] == currentPlayer && spielfeld[y - 2][x + 2] == currentPlayer
								&& spielfeld[y - 3][x + 3] == 0 && spielfeld[y - 2][x + 3] != 0) {
							if (spielfeld[0][x + 3] == 0) {
								return x + 3;
							}
						}
						if (spielfeld[y - 1][x + 1] == currentPlayer && spielfeld[y - 2][x + 2] == 0
								&& spielfeld[y - 3][x + 3] == currentPlayer && spielfeld[y - 1][x + 2] != 0) {
							if (spielfeld[0][x + 2] == 0) {
								return x + 2;
							}
						}
						if (spielfeld[y - 1][x + 1] == 0 && spielfeld[y - 2][x + 2] == currentPlayer
								&& spielfeld[y - 3][x + 3] == currentPlayer && spielfeld[y][x + 1] != 0) {
							if (spielfeld[0][x + 1] == 0) {
								return x + 1;
							}
						}
						if (y != spielfeld.length - 1 && x != 0 && spielfeld[y - 1][x + 1] == currentPlayer
								&& spielfeld[y - 2][x + 2] == currentPlayer && spielfeld[y + 1][x - 1] == 0) {
							if (y != spielfeld.length - 2) {
								if (spielfeld[y + 2][x - 1] != 0) {
									if (spielfeld[0][x - 1] == 0) {
										return x - 1;
									}
								}
							} else {
								if (spielfeld[0][x - 1] == 0) {
									return x - 1;
								}
							}
						}
					}

				}
			}
			for (int y = spielfeld.length - 1; y >= 3; --y)// -4 weil sonst Gewinn nach unten nicht mgl
			{
				for (int x = spielfeld[y].length - 1; x >= 3; --x) // -4 weil sonst gewinn nach rechts nicht mgl.
				{
					if (spielfeld[y][x] == currentPlayer) {
						if (spielfeld[y - 1][x - 1] == currentPlayer && spielfeld[y - 2][x - 2] == currentPlayer
								&& spielfeld[y - 3][x - 3] == 0 && spielfeld[y - 2][x - 3] != 0) {
							if (spielfeld[0][x - 3] == 0) {
								return x - 3;
							}
						}
						if (spielfeld[y - 1][x - 1] == currentPlayer && spielfeld[y - 2][x - 2] == 0
								&& spielfeld[y - 3][x - 3] == currentPlayer && spielfeld[y - 1][x - 2] != 0) {
							if (spielfeld[0][x - 2] == 0) {
								return x - 2;
							}
						}
						if (spielfeld[y - 1][x - 1] == 0 && spielfeld[y - 2][x - 2] == currentPlayer
								&& spielfeld[y - 3][x - 3] == 0 && spielfeld[y][x - 1] != 0) {
							if (spielfeld[0][x - 1] == 0) {
								return x - 1;
							}
						}
						if (y != spielfeld.length - 1 && x != spielfeld[y].length - 1
								&& spielfeld[y - 1][x - 1] == currentPlayer
								&& spielfeld[y - 2][x - 2] == currentPlayer && spielfeld[y + 1][x + 1] == 0) {
							if (y != spielfeld.length - 2) {
								if (spielfeld[y + 2][x + 1] != 0) {
									if (spielfeld[0][x - 1] == 0) {
										return x - 1;
									}
								}
							} else {
								if (spielfeld[0][x + 1] == 0) {
									return x + 1;
								}
							}
						}
					}
				}
			}
		}

		if (kiMode == 1) {
			int x = 0;
			while (spielfeld[0][x] != 0) {
				x = (int) (Math.random() * 7);
			}
			return x;
		} else {
			return kiMedium(spielfeld);
		}

	}

	private int kiMedium(int[][] spielfeld) {
		int setX = 0;
		int random = 1 + (int) (Math.random() * 2);
		for (int currentPlayer = amountOfPlayers; currentPlayer > 0; --currentPlayer) {
			// horizontal
			for (int y = spielfeld.length - 1; y >= 0; --y) {
				for (int x = 0; x <= spielfeld[y].length - 4; ++x) // -4 weil sonst gewinn nach rechts nicht mgl.
				{
					if (spielfeld[y][x] == currentPlayer) {
						// Szenario: XX00
						if (spielfeld[y][x + 1] == currentPlayer && spielfeld[y][x + 2] == 0
								&& spielfeld[y][x + 3] == 0) {
							// falls nicht unterste Reihe
							setX = x + 1 + random;

							if (y != spielfeld.length - 1) {
								if (spielfeld[y + 1][x + 3] != 0) {
									if (spielfeld[0][setX] == 0) {
										return setX;
									}
								}
							}
							if (spielfeld[0][setX] == 0) {
								return setX;
							}						
						}
						// Szenarion X00X
						if (spielfeld[y][x + 1] == 0 && spielfeld[y][x + 2] == 0
								&& spielfeld[y][x + 3] == currentPlayer) {
							// falls nicht unterste Reihe
							setX = x + random;

							if (y != spielfeld.length - 1) {
								if (spielfeld[y + 1][x + 3] != 0) {
									if (spielfeld[0][setX] == 0) {
										return setX;
									}								}
							}
							if (spielfeld[0][setX] == 0) {
								return setX;
							}						}
						// Szenarion X0X0
						if (spielfeld[y][x + 1] == 0 && spielfeld[y][x + 2] == currentPlayer
								&& spielfeld[y][x + 3] == 0) {
							// falls nicht unterste Reihe
							setX = (int) (Math.random() * 2);
							if (random == 2) {
								setX = x + 3;
							} else {
								setX = x + 1;
							}

							if (y != spielfeld.length - 1) {
								if (spielfeld[y + 1][x + 3] != 0) {
									if (spielfeld[0][setX] == 0) {
										return setX;
									}								}
							}
							if (spielfeld[0][setX] == 0) {
								return setX;
							}						}
					}
				}
			}
		}
		int x = 0;
		do {
			x = (int) (Math.random() * 7);
		} while (spielfeld[0][x] != 0);
		return x;
	}

}
