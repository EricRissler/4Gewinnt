import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class WriterAndReaderTest {

	@Test
	void test() {

		Profilneu writerTester = new Profilneu("test");

		writerTester.writer("test"); // Erstellen des Profils test

		Profilauswahl readerTester = new Profilauswahl("test");

		assertEquals("Must return test", "test", readerTester.reader("test")); // Test ob Profil angelegt wurde und ob
																				// der Name des Profils test ist

	}

}
