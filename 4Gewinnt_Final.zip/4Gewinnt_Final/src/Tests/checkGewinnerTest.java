import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class checkGewinnerTest {

	@Test
	void test() {
		Spiel tester = new Spiel();
		
		tester.setzeStein(2, 1); //Setzen eines gelben Steines auf den Punkt (5,2)
		
		assertEquals("Must return false", false, tester.checkGewinner(5, 2)); //Da keine weiteren Steine im Feld sind wird kein Gewinner erwartet
		
		tester.setzeStein(1, 1); //Setzen zus�tzlicher Steine
		tester.setzeStein(3, 1);
		tester.setzeStein(4, 1);
		
		assertEquals("Must return true", true, tester.checkGewinner(5, 2)); //Gewinner wird erwartet
		
	}

}
