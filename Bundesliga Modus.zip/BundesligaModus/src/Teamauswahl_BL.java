import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Teamauswahl_BL extends JFrame implements ActionListener {
	private JComboBox combo1 = new JComboBox();
	private JComboBox combo2 = new JComboBox();
	// private JTextField eingabe2 = new JTextField();
	private JButton accept = new JButton("Ausw�hlen");
	private JButton back = new JButton("Zur�ck zum Men�");

	String[] teams = { "TSG Hoffenheim", "1.FC Nuernberg", "1.FSV Mainz 05", "FC Schalke 04", "Bayer Leverkusen",
			"FC Bayern", "Eintracht Frankfurt", "FC Augsburg", "Fortuna Duesseldorf", "Hannover 96", "Hertha BSC",
			"Borussia Moenchengladbach", "RB Leipzig", "SC Freiburg", "VFB Stuttgart", "VFL Wolfsburg", "Werder Bremen",
			"Borussia Dortmund" };

	public Teamauswahl_BL(String title) throws HeadlessException {
		buildWindow();

	}

	private void buildWindow() {
		setLayout(null);

		combo1 = new JComboBox(teams);
		combo1.setBounds(40, 20, 200, 30);
		add(combo1);

		combo2 = new JComboBox(teams);
		combo2.setBounds(40, 60, 200, 30);
		add(combo2);

		// eingabe.setBounds(40, 20, 200, 30);
		// add(eingabe);
		// eingabe2.setBounds(40, 60, 200, 30);
		// add(eingabe2);
		accept.setBounds(40, 100, 200, 50);
		accept.addActionListener(this);
		add(accept);
		back.setBounds(40, 160, 200, 50);
		back.addActionListener(this);
		add(back);

	}

	public static void main(String[] args) {
		Teamauswahl_BL teamauswahl = new Teamauswahl_BL("Profilauswahl");
		teamauswahl.setBounds(400, 100, 300, 300);
		teamauswahl.setVisible(true);
		teamauswahl.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		teamauswahl.setResizable(false);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object src = e.getSource();
		if (src == accept) {
			int team1 = combo1.getSelectedIndex();
			int team2 = combo2.getSelectedIndex();
			if (team1 == team2) {
				JOptionPane.showMessageDialog(null, "Nicht das gleiche Profil ausw�hlen!");
			} else {
				GUI_BL win = new GUI_BL("4Gewinnt-Bundesliga Modus");
				win.setBounds(400, 100, 600, 430);
				win.setVisible(true);
				win.setDefaultCloseOperation(EXIT_ON_CLOSE);
				win.setModi(team1, team2);
				win.setVisible(true);
				win.setResizable(false);
				dispose();
			}

		}
	}
}
