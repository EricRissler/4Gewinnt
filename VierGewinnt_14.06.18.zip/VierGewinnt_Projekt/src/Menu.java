import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class Menu extends JFrame implements ActionListener {
	private JButton start = new JButton("Start");
	private JTextField text = new JTextField();
	private JButton startMulti = new JButton("Multi");
	File file;
	FileWriter writer;
	public Menu(String title) throws HeadlessException {
		super(title);

		buildWindow();

	}
	
	
	
	
	private void buildWindow() {
		setLayout(null);
		start.setBounds(200, 100, 200, 50);
		start.addActionListener(this);
		add(start);
		text.setBounds(200, 200, 200, 30);
		add(text);
		startMulti.setBounds(200, 250, 200, 50);
		startMulti.addActionListener(this);
		add(startMulti);
	}




	public static void main(String[] args) {
		Menu win = new Menu("4 Gewinnt");
		win.setBounds(400, 100, 600, 430);
		win.setVisible(true);
		win.setDefaultCloseOperation(EXIT_ON_CLOSE);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object src = e.getSource();
		if (src == start) {
			Profilauswahl profil = new Profilauswahl("Profilauswahl");
			profil.setBounds(400, 100, 300, 200);
			profil.setVisible(true);
			profil.setDefaultCloseOperation(EXIT_ON_CLOSE);
			GUI win = new GUI("4Gewinnt");
			win.setBounds(400, 100, 600, 430);
			win.setVisible(true);
			win.setDefaultCloseOperation(EXIT_ON_CLOSE);
			win.setModi(false,"Horst",0,0,"KI",0,0);
		    win.setVisible(true);
		}
		if (src == startMulti) {
			GUI win = new GUI("4Gewinnt");
			win.setBounds(400, 100, 600, 430);
			win.setVisible(true);
			win.setDefaultCloseOperation(EXIT_ON_CLOSE);
			win.setModi(true,"Horst",0,0,"Mischael",0,0);
		    win.setVisible(true);
		}
		
	}

}
