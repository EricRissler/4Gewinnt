import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class Profilauswahl extends JFrame implements ActionListener {
	private JTextField eingabe = new JTextField();
	private JButton accept = new JButton("Ausw�hlen");

	public Profilauswahl(String title) throws HeadlessException {
		super(title);

		buildWindow();

	}

	private void buildWindow() {
		setLayout(null);
		eingabe.setBounds(10, 10, 200, 30);
		add(eingabe);
		accept.setBounds(10, 60, 200, 50);
		accept.addActionListener(this);
		add(accept);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object src = e.getSource();
		if (src == accept) {
			
		}
	}

}
