
public class Highscore {

}
