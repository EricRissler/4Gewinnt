import java.awt.HeadlessException;

public class Player {

	public String name;
	public int win;
	public int lose;
	
	public Player(String name, int win, int lose) throws HeadlessException {
		super();
		this.name=name;
		this.win=win;
		this.lose=lose;

	}
	
	public void setWins() {
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getWin() {
		return win;
	}
	public void setWin(int win) {
		this.win = win;
	}
	public int getLose() {
		return lose;
	}
	public void setLose(int lose) {
		this.lose = lose;
	}
	
}
