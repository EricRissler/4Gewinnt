import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class Profilauswahl extends JFrame implements ActionListener {
	private JTextField eingabe = new JTextField();
	private JButton accept = new JButton("Ausw�hlen");
	//private JButton neuprofil = new JButton ("Neu Anlegen");

	public Profilauswahl(String title) throws HeadlessException {
		super(title);

		buildWindow();

	}

	private void buildWindow() {
		setLayout(null);
		eingabe.setBounds(40, 35, 200, 30);
		add(eingabe);
		accept.setBounds(40, 90, 200, 50);
		accept.addActionListener(this);
		add(accept);
		
//		neuprofil.setBounds(40, 100, 200, 50);
//		neuprofil.addActionListener(this);
//		add(neuprofil);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object src = e.getSource();
		if (src == accept) {
			String profilname=eingabe.getText();

			BufferedReader bureader; 	//Lesen
//			BufferedReader bureader2;
			try 
			{
//				
				bureader = new BufferedReader(new FileReader(profilname + ".txt"));
				String zeile1=bureader.readLine();
							
				//String zeile2=bureader.readLine();	
				
				int w = Integer.parseInt(bureader.readLine());
				int l = Integer.parseInt(bureader.readLine());
				
//				
//				String zeile4=bureader2.readLine();
				
//				int w2 = Integer.parseInt(bureader2.readLine());
//				int l2 = Integer.parseInt(bureader2.readLine());
				
				
				
				//String zeile3=bureader.readLine();
			
//				GUI win = new GUI("4Gewinnt");
//				win.setBounds(400, 100, 600, 430);
//				win.setVisible(true);
//				win.setDefaultCloseOperation(EXIT_ON_CLOSE);
//				win.setModi(false,zeile1,w,l,zeile4,w2,l2);
//			    win.setVisible(true);
//				bureader.close();
				
				GUI win = new GUI("4Gewinnt");
				win.setBounds(400, 100, 600, 430);
				win.setVisible(true);
				win.setDefaultCloseOperation(EXIT_ON_CLOSE);
				win.setModi(false,zeile1,w,l,"Computer",0,0);
			    win.setVisible(true);
				bureader.close();
				dispose();
				
								
			}
			catch (IOException r)
			{
				//e.printStackTrace();
				System.out.println("Profil nicht vorhanden");
			}
			
		}
//			if (src == neuprofil)
//			{
//				String profilname=eingabe.getText();
//			
//				FileWriter writer;
//		
//			
//				try
//				{
//					writer= new FileWriter(Profil);
//			
//					writer.write(profilname);	//Name schreiben
//					//writer.write(System.getProperty("line.separator"));
//					writer.write(System.lineSeparator());
//			
//					writer.write(String.valueOf(0));	//Wins schreiben
//					writer.write(System.lineSeparator());
//			
//					writer.write(String.valueOf(0));	//Loses schreiben
//					writer.write(System.lineSeparator());
//			
//					writer.flush();
//					writer.close();
//				
//					System.out.println("Profil angelegt!");
//				
//				} 
//				catch (IOException w)
//				{
//					System.out.println("Profil konnte nicht angelegt werden");
//				}
//		
//		
//		}
	}

}
