import java.awt.HeadlessException;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JOptionPane;

public class Player {

	public String name;
	public int win;
	public int lose;
	
	public Player(String name, int win, int lose) throws HeadlessException {
		super();
		this.name=name;
		this.win=win;
		this.lose=lose;

	}
	
	public void setWinsProfil(String name,int win, int lose) {
		String profilname=name;
		String pfad = System.getenv("pathtoprofil");
		
		FileWriter writer;
		//File Profil = new File("C:/Users/Triggl3r/Desktop/Ficker/Profile/" + profilname + ".txt");
		File Profil = new File(pfad+profilname + ".txt");
		win++;
		setWin(win);
		try
		{
			writer= new FileWriter(Profil);

			writer.write(profilname);	//Name schreiben
			//writer.write(System.getProperty("line.separator"));
			writer.write(System.lineSeparator());

			writer.write(String.valueOf(win));	//Wins schreiben
			writer.write(System.lineSeparator());

			writer.write(String.valueOf(lose));	//Loses schreiben
			writer.write(System.lineSeparator());

			writer.flush();
			writer.close();
	
		} 
		catch (IOException wr)
		{
			System.out.println("Profil konnte nicht aktualisiert werden");
		}
		
	}
	public void setLosesProfil(String name,int win, int lose) {
		String profilname=name;
		String pfad = System.getenv("pathtoprofil");
		
		FileWriter writer;
		//File Profil = new File("C:/Users/Triggl3r/Desktop/Ficker/Profile/" + profilname + ".txt");
		File Profil = new File(pfad+profilname + ".txt");
		lose++;
		setLose(lose);
		try
		{
			writer= new FileWriter(Profil);

			writer.write(profilname);	//Name schreiben
			//writer.write(System.getProperty("line.separator"));
			writer.write(System.lineSeparator());

			writer.write(String.valueOf(win));	//Wins schreiben
			writer.write(System.lineSeparator());

			writer.write(String.valueOf(lose));	//Loses schreiben
			writer.write(System.lineSeparator());

			writer.flush();
			writer.close();
	
			
		} 
		catch (IOException wr)
		{
			System.out.println("Profil konnte nicht aktualisiert werden");
		}
		
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getWin() {
		return win;
	}
	public void setWin(int win) {
		this.win = win;
	}
	public int getLose() {
		return lose;
	}
	public void setLose(int lose) {
		this.lose = lose;
	}
	
}
