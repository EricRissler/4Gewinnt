import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Profilauswahl extends JFrame implements ActionListener {
	private JTextField eingabe = new JTextField();
	private JLabel label = new JLabel("Spieler 1:");
	private JButton accept = new JButton("Ausw�hlen");
	private JButton back = new JButton("Zur�ck zum Men�");
	// private JButton neuprofil = new JButton ("Neu Anlegen");
	private JComboBox combo = new JComboBox();
	

	public Profilauswahl(String title) throws HeadlessException {

		buildWindow();

	}

	private void buildWindow() {
		setLayout(null);
		// label.setBounds(40, 30, 200, 30);
		// eingabe.setBounds(40, 35, 200, 30);
		// add(eingabe);
		accept.setBounds(40, 90, 200, 50);
		accept.addActionListener(this);
		add(accept);

		//File test = new File("C:/ProfileConnect4/");
		File test = new File(System.getenv("pathtoprofil"));
		// Alle Profile auflisten...
		String[] DIR = test.list();
		for (int i = 0; i < DIR.length; i++) {

			DIR[i] = DIR[i].substring(0, DIR[i].indexOf('.'));
		}
		combo = new JComboBox(DIR);
		combo.setBounds(40, 30, 200, 50);
		add(combo);
		back.setBounds(40, 150, 200, 50);
		back.addActionListener(this);
		add(back);

		// neuprofil.setBounds(40, 100, 200, 50);
		// neuprofil.addActionListener(this);
		// add(neuprofil);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object src = e.getSource();
		if (src == accept) {
			//String profilname = eingabe.getText();
			String profilname = (String)combo.getSelectedItem();
			reader(profilname);

		}
		if (src == back) {
			Menu win = new Menu("4 Gewinnt");
			win.setBounds(400, 100, 600, 430);
			win.setVisible(true);
			win.setResizable(false);
			win.setDefaultCloseOperation(EXIT_ON_CLOSE);
			this.dispose();
		}

	}

	public String reader(String profilname) { //R�ckgabewert f�r Test
		String pfad = System.getenv("pathtoprofil");
		
		BufferedReader bureader; // Lesen
		try {
			
			bureader = new BufferedReader(new FileReader(pfad + profilname + ".txt"));
			String zeile1 = bureader.readLine();
			
			int w = Integer.parseInt(bureader.readLine());
			int l = Integer.parseInt(bureader.readLine());

			GUI win = new GUI("4Gewinnt");
			win.setBounds(400, 100, 600, 430);
			win.setVisible(true);
			win.setDefaultCloseOperation(EXIT_ON_CLOSE);
			win.setModi(false, zeile1, w, l, "Computer", 0, 0);
			win.setVisible(true);
			win.setResizable(false);
			bureader.close();
			dispose();
			return zeile1;
		} catch (IOException r) {
			System.out.println("Profil nicht vorhanden");
		}
		return "Fehler";
	}

}
