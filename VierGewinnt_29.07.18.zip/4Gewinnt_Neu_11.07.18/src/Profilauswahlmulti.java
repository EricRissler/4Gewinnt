import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


	public class Profilauswahlmulti extends JFrame implements ActionListener {
	//	private JTextField eingabe = new JTextField();
		private JComboBox combo1 = new JComboBox();
		private JComboBox combo2 = new JComboBox();
	//	private JTextField eingabe2 = new JTextField();
		private JButton accept = new JButton("Ausw�hlen");
		private JButton back = new JButton("Zur�ck zum Men�");
		

		//private JButton neuprofil = new JButton ("Neu Anlegen");

		public Profilauswahlmulti(String title) throws HeadlessException {
			super(title);

			buildWindow();

		}

		private void buildWindow() {
			setLayout(null);
			
			//File test = new File("C:/ProfileConnect4/");
			File test = new File(System.getenv("pathtoprofil"));
			
			// Alle Profile auflisten...
			String[] DIR = test.list();
			for (int i = 0; i < DIR.length; i++) {

				DIR[i] = DIR[i].substring(0, DIR[i].indexOf('.'));
			}
			combo1 = new JComboBox(DIR);
			combo1.setBounds(40, 20, 200, 30);
			add(combo1);
			
			combo2 = new JComboBox(DIR);
			combo2.setBounds(40, 60, 200, 30);
			add(combo2);
		
			
//			eingabe.setBounds(40, 20, 200, 30);
//			add(eingabe);
//			eingabe2.setBounds(40, 60, 200, 30);
//			add(eingabe2);
			accept.setBounds(40, 100, 200, 50);
			accept.addActionListener(this);
			add(accept);
			back.setBounds(40, 160, 200, 50);
			back.addActionListener(this);
			add(back);
			
			
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			Object src = e.getSource();
			if (src == accept) {
				String profilname= (String) combo1.getSelectedItem();
				String profilname2=(String) combo2.getSelectedItem();
				
				if (profilname.equals(profilname2)) {
					JOptionPane.showMessageDialog(null, "Nicht das gleiche Profil ausw�hlen!");
				}else {
				String pfad = System.getenv("pathtoprofil");
				BufferedReader bureader; 	//Lesen Spieler 1
				//BufferedReader bureader2;	//Lesen Spieler	2 
				try 
				{
					bureader = new BufferedReader(new FileReader(pfad+profilname + ".txt"));
					String name1=bureader.readLine();
					
					int w = Integer.parseInt(bureader.readLine());
					int l = Integer.parseInt(bureader.readLine());
					
					bureader.close();
					
					bureader = new BufferedReader(new FileReader(pfad+profilname2 + ".txt" ));
					String name2=bureader.readLine();
					
					int w2 = Integer.parseInt(bureader.readLine());
					int l2 = Integer.parseInt(bureader.readLine());
								
					GUI win = new GUI("4Gewinnt");
					win.setBounds(400, 100, 600, 430);
					win.setVisible(true);
					win.setDefaultCloseOperation(EXIT_ON_CLOSE);
					win.setModi(true,name1,w,l,name2,w2,l2);
				    win.setVisible(true);
				    win.setResizable(false);
					bureader.close();
					dispose();
					//Menu.dispose();
					//bureader2.close();
									
				}
				catch (IOException r)
				{
					//e.printStackTrace();
					System.out.println("Profil nicht vorhanden");
					JOptionPane.showMessageDialog(null, r);
				}
				
				
//				}
//				if (src == neuprofil)
//				{
//					String profilname=eingabe.getText();
//				
//					FileWriter writer;
//				
//					try
//					{
//						writer= new FileWriter(Profil);
//				
//						writer.write(profilname);	//Name schreiben
//						//writer.write(System.getProperty("line.separator"));
//						writer.write(System.lineSeparator());
//				
//						writer.write(String.valueOf(0));	//Wins schreiben
//						writer.write(System.lineSeparator());
//				
//						writer.write(String.valueOf(0));	//Loses schreiben
//						writer.write(System.lineSeparator());
//				
//						writer.flush();
//						writer.close();
//					
//						System.out.println("Profil angelegt!");
//					
//					} 
//					catch (IOException w)
//					{
//						System.out.println("Profil konnte nicht angelegt werden");
//					}
//			
//			
//			}
				}
		}
			if (src == back) {
				Menu win = new Menu("4 Gewinnt");
				win.setBounds(400, 100, 600, 430);
				win.setVisible(true);
				win.setResizable(false);
				win.setDefaultCloseOperation(EXIT_ON_CLOSE);
				this.dispose();
			}
	}

}