import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class Profilneu extends JFrame implements ActionListener 
{
		private JTextField eingabe = new JTextField();
		private JButton neuprofil = new JButton ("Neu Anlegen");
		private JButton schliessen = new JButton ("Schlie�en");
	
	public Profilneu(String title) throws HeadlessException {
		super();

		buildWindow();

	}

	private void buildWindow() {
		setLayout(null);
		eingabe.setBounds(40, 10, 200, 30);
		add(eingabe);
		
		neuprofil.setBounds(40, 50, 200, 50);
		neuprofil.addActionListener(this);
		add(neuprofil);
		
		schliessen.setBounds(40, 105, 200, 50);
		schliessen.addActionListener(this);
		add(schliessen);
		
		

	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{	
		Object src = e.getSource();
		if (src == neuprofil)
		{
			String profilname=	eingabe.getText();  //Profilname aus Textfeld lesen
//			File file = new File("C:/ProfileConnect4");
//			file.mkdir();
			
			writer(profilname);
//			String pfad = System.getenv("pathtoprofil");	//Pfad f�r Ordner aus Umgebungsvariable lesen
//			FileWriter writer; 
//			File Profil = new File(pfad+profilname + ".txt"); //Profil als Textdatei anlegen
//	
//			try
//			{
//				writer= new FileWriter(Profil);
//	
//				writer.write(profilname);	//Name schreiben 
//				//writer.write(System.getProperty("line.separator"));
//				writer.write(System.lineSeparator());
//	
//				writer.write(String.valueOf(0));	//Wins schreiben
//				writer.write(System.lineSeparator());
//	
//				writer.write(String.valueOf(0));	//Loses schreiben
//				writer.write(System.lineSeparator());
//	
//				writer.flush();
//				writer.close();
//		
//				System.out.println("Profil angelegt!");
//				JOptionPane.showMessageDialog(null, "Profil angelegt!");
//			} 
//			catch (IOException wr)
//			{
//				System.out.println("Profil konnte nicht angelegt werden");
//			}
//			
//

		}
		if (src == schliessen)
		{
			System.out.println("schlie�en");
			dispose();
		}
}

	public void writer(String profilname) {
		String pfad = System.getenv("pathtoprofil");	//Pfad f�r Ordner aus Umgebungsvariable lesen
		FileWriter writer; 
		File Profil = new File(pfad+profilname + ".txt"); //Profil als Textdatei anlegen

		try
		{
			writer= new FileWriter(Profil);

			writer.write(profilname);	//Name schreiben 
			writer.write(System.lineSeparator());

			writer.write(String.valueOf(0));	//Wins schreiben
			writer.write(System.lineSeparator());

			writer.write(String.valueOf(0));	//Loses schreiben
			writer.write(System.lineSeparator());

			writer.flush();
			writer.close();
	
			System.out.println("Profil angelegt!");
			JOptionPane.showMessageDialog(null, "Profil angelegt!");
		} 
		catch (IOException wr)
		{
			System.out.println("Profil konnte nicht angelegt werden");
		}
		


		
	}
}

