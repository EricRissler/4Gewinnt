import java.awt.Color;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.Timer;

public class GUI extends JFrame implements ActionListener {
	private JButton[] einwurf = new JButton[7];
	private JButton[][] spielfeld = new JButton[6][7];
	private JLabel player1 = new JLabel("Spieler 1:");
	private JLabel player2 = new JLabel("Spieler 2:");
	private JLabel erg1 = new JLabel("0");
	private JLabel erg2 = new JLabel("0");

	private JButton backToMenu = new JButton("Zur�ck zum Men�");
	private JButton newGame = new JButton("Neues Spiel");
	private JButton close = new JButton("Beenden");
	private int ergPlayer1;
	private int ergPlayer2;
	private boolean cnt = true;
	private boolean modus = true;
	Spiel game = new Spiel();
	Player p1;
	Player p2;

	public GUI(String title) throws HeadlessException {
		super(title);

		buildWindow();

	}

	public void setModi(boolean modi, String namep1, int win1, int lose1, String namep2, int win2, int lose2) {
		if (modi == false) { // Singleplayer Modus
			p1 = new Player(namep1, win1, lose1);
			p2 = new Player(namep2, 0, 0);
		} else { // Multiplayer Modus
			p1 = new Player(namep1, win1, lose1);
			p2 = new Player(namep2, win2, lose2);
		}
		modus = modi;
		player1.setBounds(370, 0, 100, 30);
		player1.setText(p1.getName() + " : ");
		player1.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.GRAY));
		add(player1);

		ergPlayer1 = game.getErg1();
		ergPlayer2 = game.getErg2();

		erg1.setBounds(470, 0, 30, 30);
		erg1.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.YELLOW));
		add(erg1);

		player2.setBounds(370, 50, 100, 30);
		player2.setText(p2.getName() + " : ");
		player2.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.GRAY));
		add(player2);

		erg2.setBounds(470, 50, 30, 30);
		erg2.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.RED));
		add(erg2);

		erg1.setText("   " + ergPlayer1);
		erg2.setText("   " + ergPlayer2);
	}

	private void buildWindow() {
		setLayout(null);

		int einwurfX = 0;
		for (int i = 0; i < 7; i++) { // Einwurfbutton auf GUI
			einwurf[i] = new JButton(new ImageIcon(getClass().getResource("/img/Pfeil1.png")));
			einwurf[i].setBounds(einwurfX, 0, 50, 50);
			add(einwurf[i]);
			einwurf[i].addActionListener(this);
			einwurfX = einwurfX + 50;
		}
		einwurfButtonGelb();

		int x = 0;
		int y = 55;
		for (int i = 0; i < 6; i++) { // Spielfeld aufbauen
			for (int k = 0; k < 7; k++) {
				spielfeld[i][k] = new JButton(new ImageIcon(getClass().getResource("/img/Feld.png")));
				spielfeld[i][k].setBounds(x, y, 50, 50);
				add(spielfeld[i][k]);
				spielfeld[i][k].setBorderPainted(false);
				x = x + 50;

			}
			x = 0;
			y = y + 50;
		}

		backToMenu.setBounds(370, 210, 200, 50);
		backToMenu.addActionListener(this);
		add(backToMenu);

		newGame.setBounds(370, 150, 200, 50);
		newGame.addActionListener(this);
		add(newGame);

		close.setBounds(370, 270, 200, 50);
		close.addActionListener(this);
		add(close);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object src = e.getSource();
		if (src == einwurf[0]) {
			if (cnt) {

				spielfeld[game.getBelegt(0)][0].setBackground(Color.YELLOW);
				game.setzeStein(0, 1);

				einwurfButtonRot();

			} else {
				spielfeld[game.getBelegt(0)][0].setBackground(Color.RED);

				einwurfButtonGelb();
				game.setzeStein(0, 2);

			}
			if (game.checkGewinner(game.getBelegt(0), 0)) {
				if (game.werHatGewonnen(game.getBelegt(0), 0)) { // wenn Gewinner Spieler 1 ist

					gewonnenPlayerOne();

				} else {

					gewonnenPlayerTwo();

				}
				game = new Spiel();
				resetGUI();
			} else {
				game.decrementBelegt(0);

				if (game.getBelegt(0) < 0) {
					einwurf[0].setEnabled(false);
				}
			}
			if (game.checkRemis()) {
				unentschieden();
			}
			if (modus) {
				cnt = !cnt;
			} else {
				kiSpielt();

			}
		}

		if (src == einwurf[1]) {
			if (cnt) {

				spielfeld[game.getBelegt(1)][1].setBackground(Color.YELLOW);

				game.setzeStein(1, 1);

				einwurfButtonRot();

			} else {
				spielfeld[game.getBelegt(1)][1].setBackground(Color.RED);

				game.setzeStein(1, 2);

				einwurfButtonGelb();

			}
			if (game.checkGewinner(game.getBelegt(1), 1)) {
				if (game.werHatGewonnen(game.getBelegt(1), 1)) { // wenn Gewinner Spieler 1 ist
					gewonnenPlayerOne();
				} else {
					gewonnenPlayerTwo();
				}
				game = new Spiel();
				resetGUI();
			} else {
				game.decrementBelegt(1);

				if (game.getBelegt(1) < 0) {
					einwurf[1].setEnabled(false);
				}
				if (game.checkRemis()) {
					unentschieden();
				}
			}
			if (modus) {
				cnt = !cnt;
			} else {
				kiSpielt();

			}
		}

		if (src == einwurf[2]) {
			if (cnt) {

				spielfeld[game.getBelegt(2)][2].setBackground(Color.YELLOW);

				game.setzeStein(2, 1);

				einwurfButtonRot();

			} else {
				spielfeld[game.getBelegt(2)][2].setBackground(Color.RED);

				game.setzeStein(2, 2);

				einwurfButtonGelb();

			}
			if (game.checkGewinner(game.getBelegt(2), 2)) {
				if (game.werHatGewonnen(game.getBelegt(2), 2)) { // wenn Gewinner Spieler 1 ist
					gewonnenPlayerOne();
				} else {
					gewonnenPlayerTwo();
				}
				game = new Spiel();
				resetGUI();
			} else {
				game.decrementBelegt(2);

				if (game.getBelegt(2) < 0) {
					einwurf[2].setEnabled(false);
				}
			}
			if (game.checkRemis()) {
				unentschieden();
			}
			if (modus) {
				cnt = !cnt;
			} else {
				kiSpielt();

			}
		}

		if (src == einwurf[3]) {
			if (cnt) {

				spielfeld[game.getBelegt(3)][3].setBackground(Color.YELLOW);

				game.setzeStein(3, 1);

				einwurfButtonRot();

			} else {
				spielfeld[game.getBelegt(3)][3].setBackground(Color.RED);

				game.setzeStein(3, 2);

				einwurfButtonGelb();

			}
			if (game.checkGewinner(game.getBelegt(3), 3)) {
				if (game.werHatGewonnen(game.getBelegt(3), 3)) { // wenn Gewinner Spieler 1 ist
					gewonnenPlayerOne();
				} else {
					gewonnenPlayerTwo();
				}
				game = new Spiel();
				resetGUI();
			} else {
				game.decrementBelegt(3);

				if (game.getBelegt(3) < 0) {
					einwurf[3].setEnabled(false);
				}
			}
			if (game.checkRemis()) {
				unentschieden();
			}
			if (modus) {
				cnt = !cnt;
			} else {
				kiSpielt();

			}
		}

		if (src == einwurf[4]) {
			if (cnt) {

				spielfeld[game.getBelegt(4)][4].setBackground(Color.YELLOW);

				game.setzeStein(4, 1);

				einwurfButtonRot();

			} else {
				spielfeld[game.getBelegt(4)][4].setBackground(Color.RED);

				game.setzeStein(4, 2);

				einwurfButtonGelb();

			}
			if (game.checkGewinner(game.getBelegt(4), 4)) {
				if (game.werHatGewonnen(game.getBelegt(4), 4)) { // wenn Gewinner Spieler 1 ist
					gewonnenPlayerOne();
				} else {
					gewonnenPlayerTwo();
				}
				game = new Spiel();
				resetGUI();
			} else {
				game.decrementBelegt(4);

				if (game.getBelegt(4) < 0) {
					einwurf[4].setEnabled(false);
				}
			}
			if (game.checkRemis()) {
				unentschieden();
			}
			if (modus) {
				cnt = !cnt;
			} else {
				kiSpielt();

			}
		}

		if (src == einwurf[5]) {
			if (cnt) {

				spielfeld[game.getBelegt(5)][5].setBackground(Color.YELLOW);

				game.setzeStein(5, 1);

				einwurfButtonRot();

			} else {
				spielfeld[game.getBelegt(5)][5].setBackground(Color.RED);

				game.setzeStein(5, 2);

				einwurfButtonGelb();

			}
			if (game.checkGewinner(game.getBelegt(5), 5)) {
				if (game.werHatGewonnen(game.getBelegt(5), 5)) { // wenn Gewinner Spieler 1 ist
					gewonnenPlayerOne();
				} else {
					gewonnenPlayerTwo();
				}
				game = new Spiel();
				resetGUI();
			} else {
				game.decrementBelegt(5);

				if (game.getBelegt(5) < 0) {
					einwurf[5].setEnabled(false);
				}
			}
			if (game.checkRemis()) {
				unentschieden();
			}
			if (modus) {
				cnt = !cnt;
			} else {
				kiSpielt();

			}
		}

		if (src == einwurf[6]) {
			if (cnt) {

				spielfeld[game.getBelegt(6)][6].setBackground(Color.YELLOW);

				game.setzeStein(6, 1);

				einwurfButtonRot();

			} else {
				spielfeld[game.getBelegt(6)][6].setBackground(Color.RED);

				game.setzeStein(6, 2);

				einwurfButtonGelb();

			}
			if (game.checkGewinner(game.getBelegt(6), 6)) {
				if (game.werHatGewonnen(game.getBelegt(6), 6)) { // wenn Gewinner Spieler 1 ist
					gewonnenPlayerOne();
				} else {
					gewonnenPlayerTwo();
				}
				game = new Spiel();
				resetGUI();
			} else {
				game.decrementBelegt(6);

				if (game.getBelegt(6) < 0) {
					einwurf[6].setEnabled(false);
				}
			}
			if (game.checkRemis()) {
				unentschieden();
			}
			if (modus) {
				cnt = !cnt;
			} else {
				kiSpielt();

			}
		}
		if (src == backToMenu) {
			this.dispose();
			Menu win = new Menu("4 Gewinnt");
			win.setBounds(400, 100, 600, 500);
			win.setVisible(true);
			win.setResizable(false);
			win.setDefaultCloseOperation(EXIT_ON_CLOSE);
		}
		if (src == close) {
			System.exit(0);
		}
		if (src == newGame) {
			resetGUI();
			game = new Spiel();
			game.setErg1(0);
			game.setErg2(0);

			ergPlayer1 = game.getErg1();
			ergPlayer2 = game.getErg2();

			erg1.setText("   " + ergPlayer1);
			erg2.setText("   " + ergPlayer2);
		}

	}

	private void gewonnenPlayerOne() {
		JOptionPane.showMessageDialog(null, p1.getName() + " hat gewonnen");
		ergPlayer1++;
		game.setErg1(ergPlayer1);
		erg1.setText("   " + game.getErg1());
		p1.setWinsProfil(p1.getName(), p1.getWin(), p1.getLose());
		if (modus == true) {
			p2.setLosesProfil(p2.getName(), p2.getWin(), p2.getLose());
		}

	}

	private void gewonnenPlayerTwo() {
		JOptionPane.showMessageDialog(null, p2.getName() + " hat gewonnen");

		ergPlayer2++;
		game.setErg2(ergPlayer2);
		erg2.setText("   " + game.getErg2());
		p1.setLosesProfil(p1.getName(), p1.getWin(), p1.getLose());
		if (modus == true) {
			p2.setWinsProfil(p2.getName(), p2.getWin(), p2.getLose());

		}

	}

	private void einwurfButtonGelb() {
		for (int i = 0; i < 7; i++) {
			einwurf[i].setBackground(Color.YELLOW);

		}

	}

	private void einwurfButtonRot() {
		for (int i = 0; i < 7; i++) {
			einwurf[i].setBackground(Color.RED);

		}

	}

	private void kiSpielt() {
		if (game.checkRemis()) {
			JOptionPane.showMessageDialog(null, "Unentschieden");
			game = new Spiel();
			resetGUI();
		} else {
			einwurfButtonGelb();
			int kiChoice = game.nextKi();
			spielfeld[game.getBelegt(kiChoice)][kiChoice].setBackground(Color.RED);
			if (game.checkRemis()) {
				JOptionPane.showMessageDialog(null, "Unentschieden");
				game = new Spiel();
				resetGUI();
			} else if (game.checkGewinner(game.getBelegt(kiChoice), kiChoice)) {
				JOptionPane.showMessageDialog(null, p2.getName() + " hat gewonnen");
				p1.setLosesProfil(p1.getName(), p1.getWin(), p1.getLose());
				ergPlayer2++;
				game.setErg2(ergPlayer2);
				erg2.setText("   " + game.getErg2());
				game = new Spiel();
				resetGUI();
			} else {
				game.decrementBelegt(kiChoice);
			}
			if (game.getBelegt(kiChoice) < 0) {
				einwurf[kiChoice].setEnabled(false);
			}
		}
	}

	private void unentschieden() {
		JOptionPane.showMessageDialog(null, "Unentschieden!");
		game = new Spiel();
		resetGUI();
	}

	private void resetGUI() {
		for (int i = 0; i < 7; i++) {
			einwurf[i].setEnabled(true);
		}
		for (int i = 0; i < 6; i++) {
			for (int k = 0; k < 7; k++) {
				spielfeld[i][k].setBackground(null);
			}
		}
	}

}
