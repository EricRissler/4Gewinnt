import java.awt.HeadlessException;

public class KI {
	public KI() throws HeadlessException {
		super();
	}

	public int wirfStein() {
		return (int) (Math.random() * 7);
	}

	public int checkeGewinnKI(int belegtArray[][]) {
		return (int) (Math.random() * 7);
	}

	public int setzen(int belegtArray[][]) {
		return 0;
	}

}
