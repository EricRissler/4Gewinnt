import java.awt.Color;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class Menu extends JFrame implements ActionListener {
	private JButton start = new JButton("Singleplayer");
	private JButton beenden = new JButton("Beenden");
	private JButton startMulti = new JButton("Multiplayer");
	private JButton anlegen = new JButton("Neues Profil anlegen");
	private JButton highscore = new JButton("Highscore");
	private JButton buli = new JButton("Zusatzmodus");

	public Menu(String title) throws HeadlessException {
		super(title);

		buildWindow();

	}

	private void buildWindow() {
		setLayout(null);
		start.setBounds(200, 30, 200, 50);
		start.addActionListener(this);
		add(start);

		startMulti.setBounds(200, 100, 200, 50);
		startMulti.addActionListener(this);
		add(startMulti);

		anlegen.setBounds(200, 170, 200, 50);
		anlegen.addActionListener(this);
		add(anlegen);

		highscore.setBounds(200, 240, 200, 50);
		highscore.addActionListener(this);
		add(highscore);

		buli.setBounds(200, 310, 200, 50);
		buli.addActionListener(this);
		add(buli);

		beenden.setBounds(200, 380, 200, 50);
		beenden.addActionListener(this);
		add(beenden);

	}

	public static void main(String[] args) {
		Menu win = new Menu("4 Gewinnt Neu");
		win.setBounds(400, 100, 600, 500);
		win.setVisible(true);
		win.setResizable(false);
		win.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object src = e.getSource();
		if (src == start) {
			Profilauswahl profil = new Profilauswahl("Profilauswahl");
			profil.setBounds(500, 200, 300, 250);
			profil.setVisible(true);
			profil.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			profil.setResizable(false);
			this.dispose();

		}
		if (src == startMulti) {

			Profilauswahlmulti profil = new Profilauswahlmulti("Profilauswahl");
			profil.setBounds(500, 200, 300, 300);
			profil.setVisible(true);
			profil.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			this.dispose();

		}
		if (src == beenden) {

			System.out.println("Beenden");
			System.exit(0);
		}
		if (src == anlegen) {

			Profilneu profil = new Profilneu("Profilauswahl");
			profil.setBounds(400, 100, 300, 200);
			profil.setVisible(true);
			profil.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			profil.setResizable(false);

		}
		if (src == buli) {
			Teamauswahl_BL teamauswahl = new Teamauswahl_BL("Bundesliga Modus");
			teamauswahl.setBounds(400, 100, 300, 300);
			teamauswahl.setVisible(true);
			teamauswahl.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			teamauswahl.setResizable(false);
			this.dispose();
		}
		if (src == highscore) {
			Highscore highscore = new Highscore("Profilauswahl");
			highscore.setBounds(400, 100, 300, 300);
			highscore.setVisible(true);
			highscore.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			highscore.setResizable(false);
		}

	}

}
