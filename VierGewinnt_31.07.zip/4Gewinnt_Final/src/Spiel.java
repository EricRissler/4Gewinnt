import java.awt.HeadlessException;

import javax.swing.JOptionPane;

public class Spiel {

	private int[][] spielfeld = new int[6][7];
	private int[] belegt = new int[7];
	private int erg1;
	private int erg2;
	KI ki = new KI();
	public Spiel() throws HeadlessException {
		super();
		setErg1(0);
		setErg2(0);
		for (int i = 0; i < 7; i++) {
			belegt[i] = 5;
		}

		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				spielfeld[i][j] = 0;
			}
		}

	}

	public int nextKi() {
		int zz;
//		int zz=ki.blockUserWinningOption(belegtArray);
		do {
		zz = ki.wirfStein();
		} while (belegt[zz]<=0);
		setzeStein(zz, 2);
		return zz;
	}
	
	public void setzeStein(int x, int value) {
		spielfeld[belegt[x]][x] = value;
	}

	public boolean checkGewinner(int y, int x) {

		int tmpY = y;
		int tmpX = x;
		int cnt = 0;
		// check nach unten
		if (y + 3 > 5) {
			
		} else {

			if (spielfeld[y][x] == spielfeld[y + 1][x] && spielfeld[y][x] == spielfeld[y + 2][x]
					&& spielfeld[y][x] == spielfeld[y + 3][x]) {
				// System.out.println("Gewonnen nach Unten");
				return true;
			}
		}
		// nach links
		if ((tmpX - 1) >= 0) {

			while (spielfeld[y][x] == spielfeld[y][tmpX - 1]) {
				cnt++;
				if (cnt == 3) {
					// System.out.println("Gewonnen nach Links");
					return true;
				}
				tmpX--;
				if ((tmpX - 1) < 0) {
					break;
				}

			}
			tmpY = y;
			tmpX = x;
		}
		// nach rechts
		if ((tmpX + 1) <= 6) {

			while (spielfeld[y][x] == spielfeld[y][tmpX + 1]) {
				cnt++;
				if (cnt == 3) {
					// System.out.println("Gewonnen nach Rechts");
					return true;
				}
				tmpX++;
				if ((tmpX + 1) > 6) {
					break;
				}

			}

		}
		tmpY = y;
		tmpX = x;
		cnt = 0;
		// Diagonale links runter
		if ((tmpX - 1) >= 0 && (tmpY + 1) <= 5) {
			while (spielfeld[y][x] == spielfeld[tmpY + 1][tmpX - 1]) {
				cnt++;
				if (cnt == 3) {
					// System.out.println("Gewonnen nach Dio");
					return true;
				}
				tmpX--;
				tmpY++;
				if ((tmpX - 1) < 0 || (tmpY + 1) > 5) {
					break;
				}

			}
		}
		tmpY = y;
		tmpX = x;

		// Diagonale rechts hoch
		if ((tmpX + 1) <= 6 && (tmpY - 1) >= 0) {
			while (spielfeld[y][x] == spielfeld[tmpY - 1][tmpX + 1]) {
				cnt++;
				if (cnt == 3) {
					// System.out.println("Gewonnen nach annere Dio");
					return true;
				}
				tmpX++;
				tmpY--;
				if ((tmpX + 1) > 6 || (tmpY - 1) < 0) {
					break;
				}

			}
		}

		// -----------------------------------------------------------------

		tmpY = y;
		tmpX = x;
		cnt = 0;
		// Diagonale links hoch
		if ((tmpX - 1) >= 0 && (tmpY - 1) >= 0) {
			while (spielfeld[y][x] == spielfeld[tmpY - 1][tmpX - 1]) {
				cnt++;
				if (cnt == 3) {
					// System.out.println("Gewonnen nach Dio 2 ");
					return true;
				}
				tmpX--;
				tmpY--;
				if ((tmpX - 1) < 0 || (tmpY - 1) < 0) {
					break;
				}

			}
		}
		tmpY = y;
		tmpX = x;

		// Diagonale rechts runter
		if ((tmpX + 1) <= 6 && (tmpY + 1) <= 5) {
			while (spielfeld[y][x] == spielfeld[tmpY + 1][tmpX + 1]) {
				cnt++;
				if (cnt == 3) {
					// System.out.println("Gewonnen nach annere Dio a 2");
					return true;
				}
				tmpX++;
				tmpY++;
				if ((tmpX + 1) > 6 || (tmpY + 1) > 5) {
					break;
				}

			}
		}
		return false;
	}

	public boolean werHatGewonnen(int y, int x) {
		if (spielfeld[y][x] == 1) {
			return true;
			// JOptionPane.showMessageDialog(null, "Blau hat gewonnen");
		} else {
			return false;
			// JOptionPane.showMessageDialog(null, "Rot hat gewonnen");
		}
	}

	public void decrementBelegt(int i) {
		belegt[i] = belegt[i] - 1;
	}

	public int getBelegt(int i) {
		return belegt[i];
	}

	public int[][] getSpielfeld() {
		return spielfeld;
	}

	public void setSpielfeld(int[][] spielfeld) {
		this.spielfeld = spielfeld;
	}

	public void setBelegt(int[] belegt) {
		this.belegt = belegt;
	}

	public int getErg1() {
		return erg1;
	}

	public void setErg1(int erg1) {
		this.erg1 = erg1;
	}

	public int getErg2() {
		return erg2;
	}

	public void setErg2(int erg2) {
		this.erg2 = erg2;
	}

	public boolean checkRemis() {
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				if(spielfeld[i][j] == 0) {
					return false;
				}
			}
		}

		return true;
	}

}
