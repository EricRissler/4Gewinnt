import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class checkRemisTest {

	@Test
	void test() {
		Spiel tester = new Spiel();

		tester.setzeStein(3, 1); // Stein in Spielfeld plaziert
		assertEquals("No remis excepted", false, tester.checkRemis()); // Checken ob noch freie Felder vorhanden sind
		// ----------------------------------------------------------------------------
		int[][] testSpielfeld = new int[6][7];
		for (int i = 0; i < 6; i++) { // Komplettes Spielfeld wird belegt
			for (int j = 0; j < 7; j++) {
				testSpielfeld[i][j] = 1;
			}
		}

		tester.setSpielfeld(testSpielfeld); // Belegen des kompletten Spielfeldes

		assertEquals("Remis excepted", true, tester.checkRemis()); // Da kein freies Feld mehr vorhanden ist gehen wir
																	// hier von einem Remis aus. Gewinner wird hier
																	// nicht betachtet.

	}

}
