import java.awt.HeadlessException;

public class KI {
	public KI() throws HeadlessException {
		super();
		amountOfPlayers = 2;
	}

	public int wirfStein() {
		return (int) (Math.random() * 7);
	}

	public int checkeGewinnKI(int belegtArray[][]) {
		return (int) (Math.random() * 7);
	}

	public int setzen(int belegtArray[][]) {
		return 0;
	}

	// returns x Value to block Users Win
	public int blockUserWinningOption(int belegtArray[][]) {
		for (int currentPlayer = amountOfPlayers; currentPlayer > 0; --currentPlayer) {
			// horizontal
			for (int y = 0; y < belegtArray[1].length; ++y) {
				for (int x = 0; x < belegtArray.length - 4; ++x) // -4 weil sonst gewinn nach rechts nicht mgl.
				{
					if (belegtArray[x][y] == currentPlayer) {
						// Szenario: XXX0
						if (belegtArray[x + 1][y] == currentPlayer && belegtArray[x + 2][y] == currentPlayer
								&& belegtArray[x + 3][y] == 0) {
							// falls nicht unterste Reihe
							if (y != belegtArray[1].length - 1) {
								if (belegtArray[x + 3][y + 1] != 0) {
									return x + 3;
								}
							}
							return x + 3;
						}
						// Szenario: XX0X
						else if (belegtArray[x + 1][y] == currentPlayer && belegtArray[x + 3][y] == currentPlayer
								&& belegtArray[x + 2][y] == 0) {
							// falls nicht unterste Reihe
							if (y != belegtArray[1].length - 1) {
								if (belegtArray[x + 2][y + 1] != 0) {
									return x + 3;
								}
							}
							return x + 2;
						}
						// szenario: X0XX
						else if (belegtArray[x + 3][y] == currentPlayer && belegtArray[x + 2][y] == currentPlayer
								&& belegtArray[x + 1][y] == 0) {
							// falls nicht unterste Reihe
							if (y != belegtArray[1].length - 1) {
								if (belegtArray[x + 1][y + 1] != 0) {
									return x + 3;
								}
							}
							return x + 1;
						}
					}
				}
			}
			// vertical
			for (int x = 0; x < belegtArray.length; ++x) {
				for (int y = 0; y < belegtArray[1].length; ++y) {
					if (belegtArray[x][y] == currentPlayer) {
						if (belegtArray[x][y - 1] == currentPlayer && belegtArray[x][y - 2] == currentPlayer
								&& belegtArray[x][y - 3] == 0) {
							return x;
						}
					}
				}
			}
			// diago
			for (int y = 0; y < belegtArray[1].length - 4; ++y)// -4 weil sonst Gewinn nach oben nicht mgl
			{
				for (int x = 0; x < belegtArray.length - 4; ++x) // -4 weil sonst gewinn nach rechts nicht mgl.
				{
					if (belegtArray[x][y] == currentPlayer) {
						if (belegtArray[x - 1][y - 1] == currentPlayer && belegtArray[x - 2][y - 2] == currentPlayer
								&& belegtArray[x][y - 3] == 0) {
							return x;
						}
					}
					return 0;
				}
			}
		}
		return 0;
	}

	private int amountOfPlayers;
	// returns x value to win Game
	// private int winGame(int belegtArray[][])
	// {
	// for(int y = 0; y < belegtArray[1].length; ++y)
	// {
	// for(int x = 0; x < belegtArray.length; ++x)
	// {
	// if(belegtArray[x][y] == 2)
	// {
	// if(belegtArray[x+1][y] == 2 && belegtArray[x+2][y] == 2 &&
	// belegtArray[x+3][y] == 0 && belegtArray[x+3][y+1] != 0)
	// {
	// return x+3;
	// }
	// }
	// }
	// }
	// for(int x = 0; x < belegtArray.length; ++x)
	// {
	// for(int y = 0; y < belegtArray[1].length; ++y)
	// {
	// if(belegtArray[x][y] == 2)
	// {
	// if(belegtArray[x][y - 1] == 2 && belegtArray[x][y-2] == 2 &&
	// belegtArray[x][y-3] == 0)
	// {
	// return x;
	// }
	// }
	// }
	// }
	// }
}
