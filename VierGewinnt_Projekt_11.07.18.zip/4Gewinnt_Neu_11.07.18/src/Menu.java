import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class Menu extends JFrame implements ActionListener {
	private JButton start = new JButton("Singleplayer");
	private JButton beenden = new JButton("Beenden");
	private JButton startMulti = new JButton("Multiplayer");
	private JButton anlegen = new JButton("Neues Profil anlegen");
	private JButton highscore = new JButton("Highscore");

	File file;

	// FileWriter writer;
	public Menu(String title) throws HeadlessException {
		super(title);
	
		buildWindow();
		// JDialog(false);
	}

	private void buildWindow() {
		setLayout(null);
		start.setBounds(200, 30, 200, 50);
		start.addActionListener(this);
		add(start);
	
		startMulti.setBounds(200, 100, 200, 50);
		startMulti.addActionListener(this);
		add(startMulti);
	
		anlegen.setBounds(200, 170, 200, 50);
		anlegen.addActionListener(this);
		add(anlegen);
	
		highscore.setBounds(200, 240, 200, 50);
		highscore.addActionListener(this);
		add(highscore);
	
		beenden.setBounds(200, 310, 200, 50);
		beenden.addActionListener(this);
		add(beenden);
	
	}

	public static void main(String[] args) {
		Menu win = new Menu("4 Gewinnt Neu");
		win.setBounds(400, 100, 600, 430);
		win.setVisible(true);
		win.setResizable(false);
		win.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object src = e.getSource();
		if (src == start) {
			Profilauswahl profil = new Profilauswahl("Profilauswahl");
			profil.setBounds(500, 200, 300, 250);
			profil.setVisible(true);
			profil.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			profil.setResizable(false);
			this.dispose();
			// GUI win = new GUI("4Gewinnt");
			// win.setBounds(400, 100, 600, 430);
			// win.setVisible(true);
			// win.setDefaultCloseOperation(EXIT_ON_CLOSE);
			// win.setModi(false,profilname,0,0,"KI",0,0);
			// win.setVisible(true);

		}
		if (src == startMulti) {

			Profilauswahlmulti profil = new Profilauswahlmulti("Profilauswahl");
			profil.setBounds(500, 200, 300, 300);
			profil.setVisible(true);
			profil.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			this.dispose();
			// GUI win = new GUI("4Gewinnt");
			// win.setBounds(400, 100, 600, 430);
			// win.setVisible(true);
			// win.setDefaultCloseOperation(EXIT_ON_CLOSE);
			// win.setModi(true,"Horst",0,0,"Mischael",0,0);
			// win.setVisible(true);
		}
		if (src == beenden) {

			System.out.println("Beenden");
			System.exit(0);
		}
		if (src == anlegen) {
			
			Profilneu profil = new Profilneu("Profilauswahl");
			profil.setBounds(400, 100, 300, 200);
			profil.setVisible(true);
			profil.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			profil.setResizable(false);
			

		}
		if (src == highscore) {
			Highscore highscore = new Highscore("Profilauswahl");
			highscore.setBounds(400, 100, 300, 300);
			highscore.setVisible(true);
			highscore.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			highscore.setResizable(false);
		}

	}

}
